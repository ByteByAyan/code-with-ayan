# SmartDust AI — Team GLITCH

A Flask + SQLite environmental-monitoring prototype with a responsive dashboard, sample pollution history, threshold alerts, a simple transparent trend estimate, an interactive map, and optional external weather/air-quality data.

## Features

- Responsive dark dashboard with PM₂.₅, PM₁₀, temperature, and humidity cards.
- Historical sample chart powered by Chart.js.
- Interactive OpenStreetMap map powered by Leaflet; click a point or use browser location permission.
- Weather and air-quality conditions from Open-Meteo (requires internet access; provider availability can vary).
- Air-quality threshold flags and optional browser notifications.
- Login and registration with Werkzeug password hashing.
- Demo reading generator and JSON endpoints for future sensor integration.
- `/health` health-check endpoint.

## Important data limitations

**This is a prototype, not a live sensor network.** Initial readings and the “Generate sample” button use simulated data. The AI trend outlook is a simple linear trend extrapolation over recent samples; it is not a trained or validated machine-learning model and should not be used for health, regulatory, or emergency decisions. Open-Meteo values are external model/provider data for the selected coordinates, not readings from the demo sensor. AQI is the European AQI scale returned by the provider.

Thresholds in `app.py` (PM₂.₅ = 35 µg/m³ and PM₁₀ = 100 µg/m³) are prototype triggers only. Confirm thresholds with your mentor and applicable local standards before presenting them as official limits.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set a secret key before running in any shared environment:

```bash
# Windows PowerShell
$env:SMARTDUST_SECRET_KEY = "replace-with-a-long-random-secret"
python app.py
```

Open http://127.0.0.1:5000. Create your own account on the registration page. Do not use a shared/public deployment without setting `SMARTDUST_SECRET_KEY`, protecting sensor ingestion, and choosing persistent storage.

## Deploy on Render

- Create a **Python web service** connected to this repository.
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- Add environment variable `SMARTDUST_SECRET_KEY` with a long random value.
- Commit the files in this layout:

```text
app.py
requirements.txt
.gitignore
README.md
templates/login.html
templates/dashboard.html
static/style.css
static/dashboard.js
```

SQLite on a free/ephemeral service may not persist reliably across restarts or redeploys. For a lasting deployment, configure a persistent disk or move to a managed database. Do not commit `smartdust.db` or secrets to GitHub.

## Endpoints

- `GET /health` — basic health check
- `GET /api/readings?limit=48` — recent readings (login required)
- `GET /api/latest` — latest reading (login required)
- `POST /api/demo-reading` — append a simulated reading (login required)
- `POST /api/readings` — reserved sensor ingestion endpoint; add device authentication before production use
- `GET /api/audit-logs` — recent audit events (login required)

## Security notes

This is a hackathon prototype. The sensor ingestion endpoint currently accepts JSON without device authentication; add authentication/rate limiting before exposing it to the public. Configure the secret key, use HTTPS, and consider CSRF protection and persistent storage before production use.
