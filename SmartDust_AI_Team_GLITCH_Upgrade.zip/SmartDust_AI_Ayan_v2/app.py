from datetime import datetime, timezone
from functools import wraps
import os, sqlite3
from flask import Flask, jsonify, render_template, request, session, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get('SMARTDUST_DB_PATH', os.path.join(APP_DIR, 'smartdust.db'))
app = Flask(__name__)
app.secret_key = os.environ.get('SMARTDUST_SECRET_KEY', 'dev-only-change-this-secret-set-env-before-deploy')
PM25_ALERT_THRESHOLD = 35.0
PM10_ALERT_THRESHOLD = 100.0

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn

def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

def log_event(event_type, details):
    with get_db() as conn:
        conn.execute('INSERT INTO audit_logs(event_type, details, created_at) VALUES (?, ?, ?)', (event_type, details, utc_now()))

def init_db():
    os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)
    with get_db() as conn:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS readings (id INTEGER PRIMARY KEY AUTOINCREMENT, site_id TEXT NOT NULL, pm25 REAL NOT NULL, pm10 REAL NOT NULL, temperature REAL, humidity REAL, wind_speed REAL, source TEXT NOT NULL DEFAULT 'demo', created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, event_type TEXT NOT NULL, details TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
        ''')
        count = conn.execute('SELECT COUNT(*) n FROM readings').fetchone()['n']
        if count == 0:
            samples = [(18,42),(24,58),(39,108),(32,89),(21,52),(27,67),(31,81),(22,49),(19,45),(28,73),(34,95),(25,61)]
            for i,(p25,p10) in enumerate(samples):
                conn.execute('INSERT INTO readings(site_id,pm25,pm10,temperature,humidity,wind_speed,source,created_at) VALUES(?,?,?,?,?,?,?,?)', ('SITE-DEMO',p25,p10,28+(i%5),48+(i%6)*3,5+(i%4)*2,'demo',utc_now()))
            conn.execute('INSERT INTO audit_logs(event_type,details,created_at) VALUES(?,?,?)', ('APP_INITIALIZED','Demo data created. Values are illustrative, not live sensor measurements.',utc_now()))

def status_for(pm25, pm10):
    if pm25 >= PM25_ALERT_THRESHOLD or pm10 >= PM10_ALERT_THRESHOLD: return 'Alert'
    if pm25 >= 25 or pm10 >= 75: return 'Elevated'
    return 'Normal'

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if 'username' not in session: return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)
    return wrapped

@app.route('/login', methods=['GET','POST'])
def login():
    if session.get('username'): return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        with get_db() as conn: user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session.clear(); session['username'] = username
            log_event('LOGIN_SUCCESS', f"User '{username}' logged in.")
            return redirect(url_for('dashboard'))
        flash('That username or password did not match.', 'error')
    return render_template('login.html', mode='login')

@app.route('/register', methods=['GET','POST'])
def register():
    if session.get('username'): return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username','').strip()
        password = request.form.get('password','')
        if len(username) < 3 or len(username) > 32 or not username.replace('_','').isalnum():
            flash('Use 3–32 letters, numbers, or underscores for the username.', 'error')
        elif len(password) < 8:
            flash('Choose a password with at least 8 characters.', 'error')
        else:
            try:
                with get_db() as conn:
                    conn.execute('INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)', (username,generate_password_hash(password),utc_now()))
                session.clear(); session['username'] = username
                log_event('REGISTER_SUCCESS', f"New account '{username}' created.")
                return redirect(url_for('dashboard'))
            except sqlite3.IntegrityError:
                flash('That username is already taken. Try another.', 'error')
    return render_template('login.html', mode='register')

@app.route('/logout', methods=['POST'])
def logout():
    username = session.get('username','unknown'); session.clear(); log_event('LOGOUT', f"User '{username}' logged out.")
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard(): return render_template('dashboard.html', username=session['username'])

@app.route('/api/readings')
@login_required
def api_readings():
    limit = max(1, min(request.args.get('limit', 48, type=int) or 48, 200))
    with get_db() as conn: rows = conn.execute('SELECT * FROM readings ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
    result=[]
    for row in reversed(rows):
        item=dict(row); item['status']=status_for(item['pm25'],item['pm10']); result.append(item)
    return jsonify(result)

@app.route('/api/latest')
@login_required
def api_latest():
    with get_db() as conn: row=conn.execute('SELECT * FROM readings ORDER BY id DESC LIMIT 1').fetchone()
    if not row: return jsonify({'error':'No readings yet'}),404
    item=dict(row); item['status']=status_for(item['pm25'],item['pm10']); item['thresholds']={'pm25_alert':PM25_ALERT_THRESHOLD,'pm10_alert':PM10_ALERT_THRESHOLD}
    item['demo_mode'] = item.get('source','demo').startswith('demo')
    return jsonify(item)

@app.route('/api/demo-reading', methods=['POST'])
@login_required
def demo_reading():
    import random
    pm25=round(random.uniform(12,58),1); pm10=round(random.uniform(30,135),1); temp=round(random.uniform(25,35),1); hum=round(random.uniform(35,78),1); wind=round(random.uniform(2,18),1); timestamp=utc_now(); status=status_for(pm25,pm10)
    with get_db() as conn: conn.execute('INSERT INTO readings(site_id,pm25,pm10,temperature,humidity,wind_speed,source,created_at) VALUES(?,?,?,?,?,?,?,?)',('SITE-DEMO',pm25,pm10,temp,hum,wind,'demo-button',timestamp))
    log_event('DEMO_READING_CREATED',f'pm25={pm25}; pm10={pm10}; status={status}')
    if status=='Alert': log_event('POLLUTION_THRESHOLD_EXCEEDED',f'pm25={pm25}; pm10={pm10}')
    return jsonify({'ok':True,'status':status,'created_at':timestamp})

@app.route('/api/audit-logs')
@login_required
def api_audit_logs():
    with get_db() as conn: rows=conn.execute('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 20').fetchall()
    return jsonify([dict(r) for r in rows])

@app.route('/health')
def health(): return jsonify({'ok':True,'service':'SmartDust AI'})

@app.errorhandler(404)
def not_found(_):
    if request.path.startswith('/api/'): return jsonify({'error':'Endpoint not found'}),404
    return 'Page not found',404

init_db()
if __name__ == '__main__': app.run(host='127.0.0.1',port=5000,debug=True)
