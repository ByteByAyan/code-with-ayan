(() => {
  const $ = (id) => document.getElementById(id);
  let trendChart = null, map = null, marker = null, selected = { lat: 20.5937, lon: 78.9629, label: 'India overview' }, refreshTimer = null;
  const fmt = (n, digits = 1) => Number.isFinite(Number(n)) ? Number(n).toFixed(digits).replace(/\.0$/, '') : '--';
  function toast(message, kind = 'info') { const node = document.createElement('div'); node.className = `toast ${kind}`; node.textContent = message; $('toast-region').appendChild(node); setTimeout(() => node.remove(), 4200); }
  async function api(path, options) { const r = await fetch(path, options); if (r.redirected && r.url.includes('/login')) { location.href = '/login'; throw new Error('Session expired'); } if (!r.ok) throw new Error(`Request failed (${r.status})`); return r.json(); }
  function setStatus(el, label) { el.textContent = label; el.className = 'status-pill ' + (label === 'Alert' ? 'danger' : label === 'Elevated' ? 'warning' : label === 'Normal' ? 'good' : 'neutral'); }
  function initChart(rows) {
    if (!window.Chart) return;
    const labels = rows.map((r, i) => { const d = new Date(r.created_at); return Number.isNaN(d.getTime()) ? `#${i + 1}` : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); });
    const data = { labels, datasets: [
      { label: 'PM₂.₅', data: rows.map(r => r.pm25), borderColor: '#63e6be', backgroundColor: 'rgba(99,230,190,.10)', borderWidth: 2.5, pointRadius: 2, pointHoverRadius: 5, tension: .38, fill: true },
      { label: 'PM₁₀', data: rows.map(r => r.pm10), borderColor: '#a99aff', backgroundColor: 'rgba(169,154,255,.04)', borderWidth: 2.2, pointRadius: 2, pointHoverRadius: 5, tension: .38, fill: false }
    ]};
    if (trendChart) { trendChart.data = data; trendChart.update(); return; }
    trendChart = new Chart($('trend-chart'), { type: 'line', data, options: { responsive: true, maintainAspectRatio: false, interaction: { intersect: false, mode: 'index' }, plugins: { legend: { display: false }, tooltip: { backgroundColor: '#101e2d', titleColor: '#f2f7fb', bodyColor: '#b7c7d6', padding: 12, displayColors: true } }, scales: { x: { grid: { display: false }, ticks: { color: '#73869a', maxTicksLimit: 7, maxRotation: 0 }, border: { display: false } }, y: { beginAtZero: true, grid: { color: 'rgba(150,170,190,.10)' }, ticks: { color: '#73869a' }, border: { display: false }, title: { display: true, text: 'µg/m³', color: '#73869a' } } } } });
  }
  function estimate(rows) {
    const recent = rows.slice(-6).map(r => Number(r.pm25)).filter(Number.isFinite); if (!recent.length) return null;
    // Transparent simple linear trend extrapolation; deliberately not presented as a validated ML model.
    const n = recent.length, meanX = (n - 1) / 2, meanY = recent.reduce((a,b) => a+b,0) / n;
    let numerator = 0, denominator = 0; recent.forEach((y, x) => { numerator += (x - meanX) * (y - meanY); denominator += (x - meanX) ** 2; });
    const slope = denominator ? numerator / denominator : 0; return Math.max(0, Math.min(500, meanY + slope));
  }
  function renderAlerts(latest) {
    const list = $('alerts-list'); const alerts = [];
    if (latest.pm25 >= 35) alerts.push({ kind: 'danger', icon: '!', title: 'PM₂.₅ threshold exceeded', body: `Latest sample is ${fmt(latest.pm25)} µg/m³; the prototype alert threshold is 35 µg/m³.` });
    else if (latest.pm25 >= 25) alerts.push({ kind: 'warning', icon: '↗', title: 'PM₂.₅ is elevated', body: `Latest sample is ${fmt(latest.pm25)} µg/m³. Keep monitoring the trend.` });
    if (latest.pm10 >= 100) alerts.push({ kind: 'danger', icon: '!', title: 'PM₁₀ threshold exceeded', body: `Latest sample is ${fmt(latest.pm10)} µg/m³; the prototype alert threshold is 100 µg/m³.` });
    if (!alerts.length) alerts.push({ kind: 'good', icon: '✓', title: 'No threshold alerts', body: 'Latest demo sample is below the configured prototype thresholds.' });
    $('alert-count').textContent = `${alerts.filter(a => a.kind !== 'good').length} alert${alerts.filter(a => a.kind !== 'good').length === 1 ? '' : 's'}`; $('nav-alert-count').textContent = alerts.filter(a => a.kind !== 'good').length;
    list.innerHTML = alerts.map(a => `<div class="alert-row ${a.kind}"><span class="alert-symbol">${a.icon}</span><div><strong>${a.title}</strong><p>${a.body}</p></div><span class="alert-source">DEMO RULE</span></div>`).join('');
    if (alerts.some(a => a.kind === 'danger') && Notification.permission === 'granted') new Notification('SmartDust AI air-quality alert', { body: alerts.filter(a => a.kind === 'danger').map(a => a.title).join(' · ') });
  }
  async function loadDashboard(showToast = false) {
    try {
      const rows = await api('/api/readings?limit=48'); if (!rows.length) throw new Error('No readings are available.');
      const latest = rows[rows.length - 1]; $('pm25-value').textContent = fmt(latest.pm25); $('pm10-value').textContent = fmt(latest.pm10); $('temperature-value').textContent = fmt(latest.temperature, 0); $('humidity-value').textContent = fmt(latest.humidity, 0);
      setStatus($('pm25-status'), latest.pm25 >= 35 ? 'Alert' : latest.pm25 >= 25 ? 'Elevated' : 'Normal'); setStatus($('pm10-status'), latest.pm10 >= 100 ? 'Alert' : latest.pm10 >= 75 ? 'Elevated' : 'Normal');
      $('pm10-bar').style.width = `${Math.min(100, Number(latest.pm10) / 150 * 100)}%`; $('humidity-bar').style.width = `${Math.min(100, Number(latest.humidity) || 0)}%`;
      $('last-updated').textContent = new Date(latest.created_at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      initChart(rows); const predicted = estimate(rows); $('prediction-value').textContent = predicted === null ? '--' : fmt(predicted); const pStatus = predicted >= 35 ? 'Alert' : predicted >= 25 ? 'Elevated' : 'Normal'; setStatus($('prediction-status'), pStatus); $('prediction-note').textContent = predicted === null ? 'Not enough samples to estimate a trend.' : `The recent sample trend points to ${pStatus.toLowerCase()} PM₂.₅ levels in the next sample. This is a simple extrapolation, not a validated AI model.`;
      renderAlerts(latest); if (showToast) toast('Dashboard refreshed.', 'success');
    } catch (e) { if (showToast) toast(e.message || 'Could not refresh dashboard.', 'error'); console.error(e); }
  }
  async function loadWeather(lat, lon, label) {
    $('weather-location').textContent = label || 'Selected map location'; $('location-label').textContent = label || `${lat.toFixed(2)}, ${lon.toFixed(2)}`;
    $('weather-note').textContent = 'Connecting to Open-Meteo weather and air-quality services…';
    try {
      const [weatherResp, airResp] = await Promise.all([
        fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,wind_speed_10m&timezone=auto`),
        fetch(`https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&current=european_aqi,pm2_5,pm10&timezone=auto`)
      ]);
      if (!weatherResp.ok || !airResp.ok) throw new Error('Weather provider unavailable'); const weather = await weatherResp.json(), air = await airResp.json(); const w = weather.current || {}, a = air.current || {};
      $('weather-temp').textContent = Number.isFinite(w.temperature_2m) ? `${Math.round(w.temperature_2m)}°` : '--°'; $('weather-humidity').textContent = Number.isFinite(w.relative_humidity_2m) ? `${w.relative_humidity_2m}%` : '--%'; $('weather-wind').textContent = Number.isFinite(w.wind_speed_10m) ? `${Math.round(w.wind_speed_10m)} km/h` : '-- km/h'; $('weather-aqi').textContent = Number.isFinite(a.european_aqi) ? Math.round(a.european_aqi) : '--'; $('weather-pm25').textContent = Number.isFinite(a.pm2_5) ? `${fmt(a.pm2_5)} µg/m³` : '-- µg/m³';
      $('weather-note').textContent = `External data from Open-Meteo · ${w.time || 'current conditions'}. Provider availability and coverage may vary.`;
    } catch (_) { $('weather-note').textContent = 'Live weather/AQI data could not be loaded. Check your connection; demo sensor readings remain separate.'; }
  }
  function initMap() {
    if (!window.L) { $('pollution-map').innerHTML = '<div class="map-fallback">Map library did not load. Check network access and refresh.</div>'; return; }
    map = L.map('pollution-map', { scrollWheelZoom: false }).setView([selected.lat, selected.lon], 4);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    marker = L.marker([selected.lat, selected.lon]).addTo(map).bindPopup('Selected monitoring point · demo sensor');
    map.on('click', e => { selected = { lat: e.latlng.lat, lon: e.latlng.lng, label: `${e.latlng.lat.toFixed(3)}, ${e.latlng.lng.toFixed(3)}` }; marker.setLatLng(e.latlng); loadWeather(selected.lat, selected.lon, selected.label); });
    loadWeather(selected.lat, selected.lon, selected.label);
  }
  $('refresh-btn').addEventListener('click', () => loadDashboard(true));
  $('sample-btn').addEventListener('click', async () => { const btn = $('sample-btn'); btn.disabled = true; try { await api('/api/demo-reading', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); await loadDashboard(); toast('New illustrative sample added.', 'success'); } catch (e) { toast('Could not add a sample. Please try again.', 'error'); } finally { btn.disabled = false; } });
  $('locate-btn').addEventListener('click', () => { if (!navigator.geolocation) { toast('Location is not available in this browser.', 'error'); return; } navigator.geolocation.getCurrentPosition(pos => { selected = { lat: pos.coords.latitude, lon: pos.coords.longitude, label: 'Your approximate location' }; if (map) { map.setView([selected.lat, selected.lon], 10); marker.setLatLng([selected.lat, selected.lon]); } loadWeather(selected.lat, selected.lon, selected.label); }, () => toast('Location permission was not granted. Click the map to choose a location.', 'error'), { timeout: 8000 }); });
  $('mobile-menu').addEventListener('click', () => $('sidebar').classList.toggle('sidebar-open'));
  document.querySelectorAll('.nav-link').forEach(a => a.addEventListener('click', () => $('sidebar').classList.remove('sidebar-open')));
  if ('Notification' in window && Notification.permission === 'default') { /* Notifications are requested only after explicit user intent. */ }
  $('alert-count').addEventListener('click', () => {});
  // Ask permission after the user clicks the alerts heading, not automatically.
  document.querySelector('#alerts .panel-heading h2').addEventListener('click', async () => { if ('Notification' in window && Notification.permission === 'default') { const result = await Notification.requestPermission(); toast(result === 'granted' ? 'Desktop notifications enabled.' : 'Desktop notifications were not enabled.'); } });
  loadDashboard(); initMap(); refreshTimer = setInterval(() => loadDashboard(), 45000);
  window.addEventListener('beforeunload', () => clearInterval(refreshTimer));
})();
